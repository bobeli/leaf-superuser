var s = document.createElement("SCRIPT");
s.innerHTML = AppsgeyserJSInterface.getFileContents("user_custom_script.js");
document.body.appendChild(s);